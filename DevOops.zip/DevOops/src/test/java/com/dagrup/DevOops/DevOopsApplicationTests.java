package com.dagrup.DevOops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevOopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
